README.txt

MyFacebook
Social media project to improve understanding of access control

COMPILATION
- Change into MyFacebook/src directory
	- EXECUTE:
		javac --release 8 access.java
		java access mytest.txt